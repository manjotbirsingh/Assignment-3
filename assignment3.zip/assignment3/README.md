# Assignment 3 CRUD APP using nodejs, mongodb, React
In this project, we are going to create node CRUD application with express and mongodb.

#### To Run this project Clone it and install modules using
```
npm install
```


```
npm start
```

E
